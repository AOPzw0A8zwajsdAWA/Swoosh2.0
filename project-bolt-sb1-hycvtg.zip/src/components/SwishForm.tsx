import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { IoClose, IoHelpCircleOutline } from 'react-icons/io5';
import { SwishFormData } from '../types';

interface SwishFormProps {
  onSubmit: (data: SwishFormData) => void;
  onClose: () => void;
}

export const SwishForm: React.FC<SwishFormProps> = ({ onSubmit, onClose }) => {
  const [formData, setFormData] = useState<SwishFormData>({
    recipient: '',
    phoneNumber: '',
    amount: '',
    message: ''
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSubmit(formData);
  };

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setFormData(prev => ({
      ...prev,
      [e.target.name]: e.target.value
    }));
  };

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="fixed inset-0 bg-[#1C1C1E]"
    >
      <div className="flex flex-col h-full">
        <div className="flex items-center justify-between p-4">
          <button onClick={onClose}>
            <IoClose className="w-6 h-6 text-white" />
          </button>
          <span className="text-white text-lg font-medium">Swisha</span>
          <IoHelpCircleOutline className="w-6 h-6 text-white" />
        </div>

        <div className="flex space-x-2 px-4 mb-6">
          <button className="flex-1 py-2 px-4 rounded-full text-sm font-medium bg-[#00A9CE] text-white">
            Vanlig
          </button>
          <button className="flex-1 py-2 px-4 rounded-full text-sm font-medium border border-[#00A9CE] text-[#00A9CE]">
            Företag
          </button>
        </div>

        <form onSubmit={handleSubmit} className="flex-1 flex flex-col px-4">
          <div className="space-y-6 flex-1">
            <div>
              <label className="text-gray-400 text-sm">Mottagare</label>
              <input
                type="text"
                name="recipient"
                value={formData.recipient}
                onChange={handleChange}
                className="w-full bg-transparent border-b border-gray-700 py-2 text-white focus:outline-none focus:border-[#00A9CE]"
              />
            </div>

            <div>
              <label className="text-gray-400 text-sm">Telefonnummer</label>
              <input
                type="tel"
                name="phoneNumber"
                value={formData.phoneNumber}
                onChange={handleChange}
                className="w-full bg-transparent border-b border-gray-700 py-2 text-white focus:outline-none focus:border-[#00A9CE]"
              />
            </div>

            <div>
              <label className="text-gray-400 text-sm">Belopp</label>
              <input
                type="number"
                name="amount"
                value={formData.amount}
                onChange={handleChange}
                className="w-full bg-transparent border-b border-gray-700 py-2 text-white focus:outline-none focus:border-[#00A9CE]"
              />
            </div>

            <div>
              <label className="text-gray-400 text-sm">Meddelande</label>
              <input
                type="text"
                name="message"
                value={formData.message}
                onChange={handleChange}
                className="w-full bg-transparent border-b border-gray-700 py-2 text-white focus:outline-none focus:border-[#00A9CE]"
              />
            </div>
          </div>

          <div className="py-6">
            <button
              type="submit"
              className="w-full bg-[#00A9CE] text-white py-3 rounded-full font-medium"
            >
              Swisha
            </button>
          </div>
        </form>
      </div>
    </motion.div>
  );
};