import React from 'react';
import { motion } from 'framer-motion';
import { format } from 'date-fns';
import { sv } from 'date-fns/locale';
import { PaymentDetails } from '../types';
import { IoClose } from 'react-icons/io5';

interface SuccessScreenProps {
  payment: PaymentDetails;
  onClose: () => void;
}

export const SuccessScreen: React.FC<SuccessScreenProps> = ({ payment, onClose }) => {
  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="fixed inset-0 bg-[#1C1C1E]"
    >
      <div className="h-full flex flex-col">
        <div className="flex-1 relative">
          <div className="absolute inset-0 bg-gradient-to-b from-green-500 to-green-600">
            <div className="absolute inset-0 opacity-30">
              {[...Array(50)].map((_, i) => (
                <div
                  key={i}
                  className="absolute rounded-full bg-white"
                  style={{
                    left: `${Math.random() * 100}%`,
                    top: `${Math.random() * 100}%`,
                    width: `${Math.random() * 6 + 2}px`,
                    height: `${Math.random() * 6 + 2}px`,
                    opacity: Math.random() * 0.5 + 0.2,
                  }}
                />
              ))}
            </div>
            <div className="h-full flex flex-col items-center justify-center text-white p-4">
              <div className="rounded-full border-2 border-white p-2 mb-4">
                <svg className="w-8 h-8" viewBox="0 0 24 24" fill="none" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                </svg>
              </div>
              <h2 className="text-2xl font-medium mb-1">Din betalning är skickad!</h2>
            </div>
          </div>
        </div>
        
        <div className="bg-[#1C1C1E] p-6 space-y-4">
          <p className="text-gray-400 text-center">
            {format(payment.timestamp, "d MMM yyyy, 'kl' HH:mm", { locale: sv })}
          </p>
          <div className="text-center">
            <p className="text-white text-lg">{payment.recipient}</p>
            <p className="text-gray-400">+{payment.phoneNumber}</p>
          </div>
          <p className="text-white text-center text-3xl font-medium">
            {payment.amount} kr
          </p>
          {payment.message && (
            <p className="text-gray-400 text-center">{payment.message}</p>
          )}
          
          <div className="pt-4">
            <img src="/swish-logo-color.svg" alt="Swish" className="h-6 mx-auto opacity-50" />
          </div>
        </div>

        <button
          onClick={onClose}
          className="absolute top-4 right-4 text-white rounded-full bg-black/20 p-2"
        >
          <IoClose className="w-6 h-6" />
        </button>
      </div>
    </motion.div>
  );
};