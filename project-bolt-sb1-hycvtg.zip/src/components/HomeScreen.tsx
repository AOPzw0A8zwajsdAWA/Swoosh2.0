import React from 'react';
import { motion } from 'framer-motion';
import { NavigationBar } from './NavigationBar';

interface HomeScreenProps {
  onSwishClick: () => void;
}

export const HomeScreen: React.FC<HomeScreenProps> = ({ onSwishClick }) => {
  return (
    <motion.div 
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="min-h-screen bg-[#1C1C1E] flex flex-col"
    >
      <div className="flex-1 flex flex-col items-center justify-center p-4">
        <img src="/nordea-logo.svg" alt="Nordea" className="h-8 mb-8" />
        <div className="w-32 h-32 mb-32">
          <img src="/swish-loading.svg" alt="Swish" className="w-full h-full" />
        </div>
        <div className="w-full max-w-xs space-y-4">
          <button
            onClick={onSwishClick}
            className="w-full bg-[#00A9CE] text-white py-3 px-6 rounded-full font-medium"
          >
            Swisha
          </button>
          <button className="w-full bg-transparent border-2 border-[#1C1C1E] text-[#00A9CE] py-3 px-6 rounded-full font-medium">
            Skanna
          </button>
        </div>
      </div>
      <NavigationBar />
    </motion.div>
  );
};