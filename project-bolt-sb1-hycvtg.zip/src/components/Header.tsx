import React from 'react';
import { IoClose, IoHelpCircleOutline } from 'react-icons/io5';

export const Header: React.FC = () => {
  return (
    <div className="flex items-center justify-between p-4 text-white">
      <IoClose className="text-2xl" />
      <span className="text-lg font-medium">Swisha</span>
      <IoHelpCircleOutline className="text-2xl" />
    </div>
  );
};