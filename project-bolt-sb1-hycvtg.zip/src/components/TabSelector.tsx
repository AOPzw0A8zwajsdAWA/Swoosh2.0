import React from 'react';
import { clsx } from 'clsx';

interface TabSelectorProps {
  activeTab: 'regular' | 'business';
  onTabChange: (tab: 'regular' | 'business') => void;
}

export const TabSelector: React.FC<TabSelectorProps> = ({ activeTab, onTabChange }) => {
  return (
    <div className="flex space-x-2 px-4 mb-6">
      <button
        onClick={() => onTabChange('regular')}
        className={clsx(
          'flex-1 py-2 px-4 rounded-full text-sm font-medium transition-colors',
          activeTab === 'regular'
            ? 'bg-[#00A9CE] text-white'
            : 'bg-transparent text-[#00A9CE] border border-[#00A9CE]'
        )}
      >
        Vanlig
      </button>
      <button
        onClick={() => onTabChange('business')}
        className={clsx(
          'flex-1 py-2 px-4 rounded-full text-sm font-medium transition-colors',
          activeTab === 'business'
            ? 'bg-[#00A9CE] text-white'
            : 'bg-transparent text-[#00A9CE] border border-[#00A9CE]'
        )}
      >
        Företag
      </button>
    </div>
  );
};