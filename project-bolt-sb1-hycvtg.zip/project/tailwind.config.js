/** @type {import('tailwindcss').Config} */
export default {
  content: [
    "./index.html",
    "./src/**/*.{js,ts,jsx,tsx}",
  ],
  theme: {
    extend: {
      colors: {
        swish: {
          blue: '#00A9CE',
          dark: '#1C1C1E',
          success: '#4CAF50',
        }
      },
    },
  },
  plugins: [],
}