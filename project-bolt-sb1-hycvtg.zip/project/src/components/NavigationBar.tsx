import React from 'react';
import { IoHomeOutline, IoTimeOutline, IoPersonOutline } from 'react-icons/io5';
import { RiMoneyDollarCircleLine } from 'react-icons/ri';

export const NavigationBar: React.FC = () => {
  return (
    <nav className="fixed bottom-0 left-0 right-0 bg-[#1C1C1E] border-t border-gray-800">
      <div className="flex justify-around py-2">
        <div className="flex flex-col items-center text-gray-400">
          <IoHomeOutline className="text-2xl" />
          <span className="text-xs mt-1">Hem</span>
        </div>
        <div className="flex flex-col items-center text-gray-400">
          <RiMoneyDollarCircleLine className="text-2xl" />
          <span className="text-xs mt-1">Förfrågningar</span>
        </div>
        <div className="flex flex-col items-center text-gray-400">
          <IoTimeOutline className="text-2xl" />
          <span className="text-xs mt-1">Historik</span>
        </div>
        <div className="flex flex-col items-center text-gray-400">
          <IoPersonOutline className="text-2xl" />
          <span className="text-xs mt-1">Profil</span>
        </div>
      </div>
    </nav>
  );
};