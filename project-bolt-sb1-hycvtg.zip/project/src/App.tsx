import React, { useState } from 'react';
import { AnimatePresence } from 'framer-motion';
import { HomeScreen } from './components/HomeScreen';
import { SwishForm } from './components/SwishForm';
import { SuccessScreen } from './components/SuccessScreen';
import { Screen, SwishFormData, PaymentDetails } from './types';

function App() {
  const [currentScreen, setCurrentScreen] = useState<Screen>('home');
  const [paymentDetails, setPaymentDetails] = useState<PaymentDetails | null>(null);

  const handleSwishSubmit = (data: SwishFormData) => {
    setPaymentDetails({
      ...data,
      timestamp: new Date()
    });
    setCurrentScreen('success');
  };

  const handleClose = () => {
    setCurrentScreen('home');
    setPaymentDetails(null);
  };

  return (
    <div className="h-screen bg-[#1C1C1E]">
      <AnimatePresence mode="wait">
        {currentScreen === 'home' && (
          <HomeScreen
            key="home"
            onSwishClick={() => setCurrentScreen('payment')}
          />
        )}
        {currentScreen === 'payment' && (
          <SwishForm
            key="payment"
            onSubmit={handleSwishSubmit}
            onClose={handleClose}
          />
        )}
        {currentScreen === 'success' && paymentDetails && (
          <SuccessScreen
            key="success"
            payment={paymentDetails}
            onClose={handleClose}
          />
        )}
      </AnimatePresence>
    </div>
  );
}

export default App;