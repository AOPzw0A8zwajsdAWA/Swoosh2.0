export type TabType = 'regular' | 'business';

export interface SwishFormData {
  recipient: string;
  phoneNumber: string;
  amount: string;
  message: string;
}

export type Screen = 'home' | 'payment' | 'success';

export interface PaymentDetails {
  recipient: string;
  phoneNumber: string;
  amount: string;
  message: string;
  timestamp: Date;
}